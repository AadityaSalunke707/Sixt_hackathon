// node_modules/@lit/reactive-element/development/css-tag.js
/**
* @license
* Copyright 2019 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
var NODE_MODE = false;
var global$3 = globalThis;
/**
* Whether the current browser supports `adoptedStyleSheets`.
*/
var supportsAdoptingStyleSheets = global$3.ShadowRoot && (global$3.ShadyCSS === void 0 || global$3.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype;
var constructionToken = Symbol();
var cssTagCache = /* @__PURE__ */ new WeakMap();
/**
* A container for a string of CSS text, that may be used to create a CSSStyleSheet.
*
* CSSResult is the return value of `css`-tagged template literals and
* `unsafeCSS()`. In order to ensure that CSSResults are only created via the
* `css` tag and `unsafeCSS()`, CSSResult cannot be constructed directly.
*/
var CSSResult = class {
	constructor(cssText, strings, safeToken) {
		this["_$cssResult$"] = true;
		if (safeToken !== constructionToken) throw new Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
		this.cssText = cssText;
		this._strings = strings;
	}
	get styleSheet() {
		let styleSheet = this._styleSheet;
		const strings = this._strings;
		if (supportsAdoptingStyleSheets && styleSheet === void 0) {
			const cacheable = strings !== void 0 && strings.length === 1;
			if (cacheable) styleSheet = cssTagCache.get(strings);
			if (styleSheet === void 0) {
				(this._styleSheet = styleSheet = new CSSStyleSheet()).replaceSync(this.cssText);
				if (cacheable) cssTagCache.set(strings, styleSheet);
			}
		}
		return styleSheet;
	}
	toString() {
		return this.cssText;
	}
};
var textFromCSSResult = (value) => {
	if (value["_$cssResult$"] === true) return value.cssText;
	else if (typeof value === "number") return value;
	else throw new Error(`Value passed to 'css' function must be a 'css' function result: ${value}. Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.`);
};
/**
* Wrap a value for interpolation in a {@linkcode css} tagged template literal.
*
* This is unsafe because untrusted CSS text can be used to phone home
* or exfiltrate data to an attacker controlled site. Take care to only use
* this with trusted input.
*/
var unsafeCSS = (value) => new CSSResult(typeof value === "string" ? value : String(value), void 0, constructionToken);
/**
* A template literal tag which can be used with LitElement's
* {@linkcode LitElement.styles} property to set element styles.
*
* For security reasons, only literal string values and number may be used in
* embedded expressions. To incorporate non-literal values {@linkcode unsafeCSS}
* may be used inside an expression.
*/
var css = (strings, ...values) => {
	return new CSSResult(strings.length === 1 ? strings[0] : values.reduce((acc, v, idx) => acc + textFromCSSResult(v) + strings[idx + 1], strings[0]), strings, constructionToken);
};
/**
* Applies the given styles to a `shadowRoot`. When Shadow DOM is
* available but `adoptedStyleSheets` is not, styles are appended to the
* `shadowRoot` to [mimic the native feature](https://developer.mozilla.org/en-US/docs/Web/API/ShadowRoot/adoptedStyleSheets).
* Note, when shimming is used, any styles that are subsequently placed into
* the shadowRoot should be placed *before* any shimmed adopted styles. This
* will match spec behavior that gives adopted sheets precedence over styles in
* shadowRoot.
*/
var adoptStyles = (renderRoot, styles) => {
	if (supportsAdoptingStyleSheets) renderRoot.adoptedStyleSheets = styles.map((s) => s instanceof CSSStyleSheet ? s : s.styleSheet);
	else for (const s of styles) {
		const style = document.createElement("style");
		const nonce = global$3["litNonce"];
		if (nonce !== void 0) style.setAttribute("nonce", nonce);
		style.textContent = s.cssText;
		renderRoot.appendChild(style);
	}
};
var cssResultFromStyleSheet = (sheet) => {
	let cssText = "";
	for (const rule of sheet.cssRules) cssText += rule.cssText;
	return unsafeCSS(cssText);
};
var getCompatibleStyle = supportsAdoptingStyleSheets || NODE_MODE ? (s) => s : (s) => s instanceof CSSStyleSheet ? cssResultFromStyleSheet(s) : s;
// node_modules/@lit/reactive-element/development/reactive-element.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
/**
* Use this module if you want to create your own base class extending
* {@link ReactiveElement}.
* @packageDocumentation
*/
var { is, defineProperty, getOwnPropertyDescriptor, getOwnPropertyNames, getOwnPropertySymbols, getPrototypeOf } = Object;
var global$2 = globalThis;
var issueWarning$4;
var trustedTypes$1 = global$2.trustedTypes;
var emptyStringForBooleanAttribute = trustedTypes$1 ? trustedTypes$1.emptyScript : "";
var polyfillSupport$2 = global$2.reactiveElementPolyfillSupportDevMode;
global$2.litIssuedWarnings ??= /* @__PURE__ */ new Set();
/**
* Issue a warning if we haven't already, based either on `code` or `warning`.
* Warnings are disabled automatically only by `warning`; disabling via `code`
* can be done by users.
*/
issueWarning$4 = (code, warning) => {
	warning += ` See https://lit.dev/msg/${code} for more information.`;
	if (!global$2.litIssuedWarnings.has(warning) && !global$2.litIssuedWarnings.has(code)) {
		console.warn(warning);
		global$2.litIssuedWarnings.add(warning);
	}
};
queueMicrotask(() => {
	issueWarning$4("dev-mode", `Lit is in dev mode. Not recommended for production!`);
	if (global$2.ShadyDOM?.inUse && polyfillSupport$2 === void 0) issueWarning$4("polyfill-support-missing", "Shadow DOM is being polyfilled via `ShadyDOM` but the `polyfill-support` module has not been loaded.");
});
/**
* Useful for visualizing and logging insights into what the Lit template system is doing.
*
* Compiled out of prod mode builds.
*/
var debugLogEvent$1 = (event) => {
	if (!global$2.emitLitDebugLogEvents) return;
	global$2.dispatchEvent(new CustomEvent("lit-debug", { detail: event }));
};
var JSCompiler_renameProperty$1 = (prop, _obj) => prop;
var defaultConverter = {
	toAttribute(value, type) {
		switch (type) {
			case Boolean:
				value = value ? emptyStringForBooleanAttribute : null;
				break;
			case Object:
			case Array: value = value == null ? value : JSON.stringify(value);
		}
		return value;
	},
	fromAttribute(value, type) {
		let fromValue = value;
		switch (type) {
			case Boolean:
				fromValue = value !== null;
				break;
			case Number:
				fromValue = value === null ? null : Number(value);
				break;
			case Object:
			case Array: try {
				fromValue = JSON.parse(value);
			} catch (e) {
				fromValue = null;
			}
		}
		return fromValue;
	}
};
/**
* Change function that returns true if `value` is different from `oldValue`.
* This method is used as the default for a property's `hasChanged` function.
*/
var notEqual = (value, old) => !is(value, old);
var defaultPropertyDeclaration$1 = {
	attribute: true,
	type: String,
	converter: defaultConverter,
	reflect: false,
	useDefault: false,
	hasChanged: notEqual
};
Symbol.metadata ??= Symbol("metadata");
global$2.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
/**
* Base element class which manages element properties and attributes. When
* properties change, the `update` method is asynchronously called. This method
* should be supplied by subclasses to render updates as desired.
* @noInheritDoc
*/
var ReactiveElement = class extends HTMLElement {
	/**
	* Adds an initializer function to the class that is called during instance
	* construction.
	*
	* This is useful for code that runs against a `ReactiveElement`
	* subclass, such as a decorator, that needs to do work for each
	* instance, such as setting up a `ReactiveController`.
	*
	* ```ts
	* const myDecorator = (target: typeof ReactiveElement, key: string) => {
	*   target.addInitializer((instance: ReactiveElement) => {
	*     // This is run during construction of the element
	*     new MyController(instance);
	*   });
	* }
	* ```
	*
	* Decorating a field will then cause each instance to run an initializer
	* that adds a controller:
	*
	* ```ts
	* class MyElement extends LitElement {
	*   @myDecorator foo;
	* }
	* ```
	*
	* Initializers are stored per-constructor. Adding an initializer to a
	* subclass does not add it to a superclass. Since initializers are run in
	* constructors, initializers will run in order of the class hierarchy,
	* starting with superclasses and progressing to the instance's class.
	*
	* @nocollapse
	*/
	static addInitializer(initializer) {
		this.__prepare();
		(this._initializers ??= []).push(initializer);
	}
	/**
	* Returns a list of attributes corresponding to the registered properties.
	* @nocollapse
	* @category attributes
	*/
	static get observedAttributes() {
		this.finalize();
		return this.__attributeToPropertyMap && [...this.__attributeToPropertyMap.keys()];
	}
	/**
	* Creates a property accessor on the element prototype if one does not exist
	* and stores a {@linkcode PropertyDeclaration} for the property with the
	* given options. The property setter calls the property's `hasChanged`
	* property option or uses a strict identity check to determine whether or not
	* to request an update.
	*
	* This method may be overridden to customize properties; however,
	* when doing so, it's important to call `super.createProperty` to ensure
	* the property is setup correctly. This method calls
	* `getPropertyDescriptor` internally to get a descriptor to install.
	* To customize what properties do when they are get or set, override
	* `getPropertyDescriptor`. To customize the options for a property,
	* implement `createProperty` like this:
	*
	* ```ts
	* static createProperty(name, options) {
	*   options = Object.assign(options, {myOption: true});
	*   super.createProperty(name, options);
	* }
	* ```
	*
	* @nocollapse
	* @category properties
	*/
	static createProperty(name, options = defaultPropertyDeclaration$1) {
		if (options.state) options.attribute = false;
		this.__prepare();
		if (this.prototype.hasOwnProperty(name)) {
			options = Object.create(options);
			options.wrapped = true;
		}
		this.elementProperties.set(name, options);
		if (!options.noAccessor) {
			const key = Symbol.for(`${String(name)} (@property() cache)`);
			const descriptor = this.getPropertyDescriptor(name, key, options);
			if (descriptor !== void 0) defineProperty(this.prototype, name, descriptor);
		}
	}
	/**
	* Returns a property descriptor to be defined on the given named property.
	* If no descriptor is returned, the property will not become an accessor.
	* For example,
	*
	* ```ts
	* class MyElement extends LitElement {
	*   static getPropertyDescriptor(name, key, options) {
	*     const defaultDescriptor =
	*         super.getPropertyDescriptor(name, key, options);
	*     const setter = defaultDescriptor.set;
	*     return {
	*       get: defaultDescriptor.get,
	*       set(value) {
	*         setter.call(this, value);
	*         // custom action.
	*       },
	*       configurable: true,
	*       enumerable: true
	*     }
	*   }
	* }
	* ```
	*
	* @nocollapse
	* @category properties
	*/
	static getPropertyDescriptor(name, key, options) {
		const { get, set } = getOwnPropertyDescriptor(this.prototype, name) ?? {
			get() {
				return this[key];
			},
			set(v) {
				this[key] = v;
			}
		};
		if (get == null) {
			if ("value" in (getOwnPropertyDescriptor(this.prototype, name) ?? {})) throw new Error(`Field ${JSON.stringify(String(name))} on ${this.name} was declared as a reactive property but it's actually declared as a value on the prototype. Usually this is due to using @property or @state on a method.`);
			issueWarning$4("reactive-property-without-getter", `Field ${JSON.stringify(String(name))} on ${this.name} was declared as a reactive property but it does not have a getter. This will be an error in a future version of Lit.`);
		}
		return {
			get,
			set(value) {
				const oldValue = get?.call(this);
				set?.call(this, value);
				this.requestUpdate(name, oldValue, options);
			},
			configurable: true,
			enumerable: true
		};
	}
	/**
	* Returns the property options associated with the given property.
	* These options are defined with a `PropertyDeclaration` via the `properties`
	* object or the `@property` decorator and are registered in
	* `createProperty(...)`.
	*
	* Note, this method should be considered "final" and not overridden. To
	* customize the options for a given property, override
	* {@linkcode createProperty}.
	*
	* @nocollapse
	* @final
	* @category properties
	*/
	static getPropertyOptions(name) {
		return this.elementProperties.get(name) ?? defaultPropertyDeclaration$1;
	}
	/**
	* Initializes static own properties of the class used in bookkeeping
	* for element properties, initializers, etc.
	*
	* Can be called multiple times by code that needs to ensure these
	* properties exist before using them.
	*
	* This method ensures the superclass is finalized so that inherited
	* property metadata can be copied down.
	* @nocollapse
	*/
	static __prepare() {
		if (this.hasOwnProperty(JSCompiler_renameProperty$1("elementProperties", this))) return;
		const superCtor = getPrototypeOf(this);
		superCtor.finalize();
		if (superCtor._initializers !== void 0) this._initializers = [...superCtor._initializers];
		this.elementProperties = new Map(superCtor.elementProperties);
	}
	/**
	* Finishes setting up the class so that it's ready to be registered
	* as a custom element and instantiated.
	*
	* This method is called by the ReactiveElement.observedAttributes getter.
	* If you override the observedAttributes getter, you must either call
	* super.observedAttributes to trigger finalization, or call finalize()
	* yourself.
	*
	* @nocollapse
	*/
	static finalize() {
		if (this.hasOwnProperty(JSCompiler_renameProperty$1("finalized", this))) return;
		this.finalized = true;
		this.__prepare();
		if (this.hasOwnProperty(JSCompiler_renameProperty$1("properties", this))) {
			const props = this.properties;
			const propKeys = [...getOwnPropertyNames(props), ...getOwnPropertySymbols(props)];
			for (const p of propKeys) this.createProperty(p, props[p]);
		}
		const metadata = this[Symbol.metadata];
		if (metadata !== null) {
			const properties = litPropertyMetadata.get(metadata);
			if (properties !== void 0) for (const [p, options] of properties) this.elementProperties.set(p, options);
		}
		this.__attributeToPropertyMap = /* @__PURE__ */ new Map();
		for (const [p, options] of this.elementProperties) {
			const attr = this.__attributeNameForProperty(p, options);
			if (attr !== void 0) this.__attributeToPropertyMap.set(attr, p);
		}
		this.elementStyles = this.finalizeStyles(this.styles);
		if (this.hasOwnProperty("createProperty")) issueWarning$4("no-override-create-property", "Overriding ReactiveElement.createProperty() is deprecated. The override will not be called with standard decorators");
		if (this.hasOwnProperty("getPropertyDescriptor")) issueWarning$4("no-override-get-property-descriptor", "Overriding ReactiveElement.getPropertyDescriptor() is deprecated. The override will not be called with standard decorators");
	}
	/**
	* Takes the styles the user supplied via the `static styles` property and
	* returns the array of styles to apply to the element.
	* Override this method to integrate into a style management system.
	*
	* Styles are deduplicated preserving the _last_ instance in the list. This
	* is a performance optimization to avoid duplicated styles that can occur
	* especially when composing via subclassing. The last item is kept to try
	* to preserve the cascade order with the assumption that it's most important
	* that last added styles override previous styles.
	*
	* @nocollapse
	* @category styles
	*/
	static finalizeStyles(styles) {
		const elementStyles = [];
		if (Array.isArray(styles)) {
			const set = new Set(styles.flat(Infinity).reverse());
			for (const s of set) elementStyles.unshift(getCompatibleStyle(s));
		} else if (styles !== void 0) elementStyles.push(getCompatibleStyle(styles));
		return elementStyles;
	}
	/**
	* Returns the property name for the given attribute `name`.
	* @nocollapse
	*/
	static __attributeNameForProperty(name, options) {
		const attribute = options.attribute;
		return attribute === false ? void 0 : typeof attribute === "string" ? attribute : typeof name === "string" ? name.toLowerCase() : void 0;
	}
	constructor() {
		super();
		this.__instanceProperties = void 0;
		/**
		* True if there is a pending update as a result of calling `requestUpdate()`.
		* Should only be read.
		* @category updates
		*/
		this.isUpdatePending = false;
		/**
		* Is set to `true` after the first update. The element code cannot assume
		* that `renderRoot` exists before the element `hasUpdated`.
		* @category updates
		*/
		this.hasUpdated = false;
		/**
		* Name of currently reflecting property
		*/
		this.__reflectingProperty = null;
		this.__initialize();
	}
	/**
	* Internal only override point for customizing work done when elements
	* are constructed.
	*/
	__initialize() {
		this.__updatePromise = new Promise((res) => this.enableUpdating = res);
		this._$changedProperties = /* @__PURE__ */ new Map();
		this.__saveInstanceProperties();
		this.requestUpdate();
		this.constructor._initializers?.forEach((i) => i(this));
	}
	/**
	* Registers a `ReactiveController` to participate in the element's reactive
	* update cycle. The element automatically calls into any registered
	* controllers during its lifecycle callbacks.
	*
	* If the element is connected when `addController()` is called, the
	* controller's `hostConnected()` callback will be immediately called.
	* @category controllers
	*/
	addController(controller) {
		(this.__controllers ??= /* @__PURE__ */ new Set()).add(controller);
		if (this.renderRoot !== void 0 && this.isConnected) controller.hostConnected?.();
	}
	/**
	* Removes a `ReactiveController` from the element.
	* @category controllers
	*/
	removeController(controller) {
		this.__controllers?.delete(controller);
	}
	/**
	* Fixes any properties set on the instance before upgrade time.
	* Otherwise these would shadow the accessor and break these properties.
	* The properties are stored in a Map which is played back after the
	* constructor runs.
	*/
	__saveInstanceProperties() {
		const instanceProperties = /* @__PURE__ */ new Map();
		const elementProperties = this.constructor.elementProperties;
		for (const p of elementProperties.keys()) if (this.hasOwnProperty(p)) {
			instanceProperties.set(p, this[p]);
			delete this[p];
		}
		if (instanceProperties.size > 0) this.__instanceProperties = instanceProperties;
	}
	/**
	* Returns the node into which the element should render and by default
	* creates and returns an open shadowRoot. Implement to customize where the
	* element's DOM is rendered. For example, to render into the element's
	* childNodes, return `this`.
	*
	* @return Returns a node into which to render.
	* @category rendering
	*/
	createRenderRoot() {
		const renderRoot = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
		adoptStyles(renderRoot, this.constructor.elementStyles);
		return renderRoot;
	}
	/**
	* On first connection, creates the element's renderRoot, sets up
	* element styling, and enables updating.
	* @category lifecycle
	*/
	connectedCallback() {
		this.renderRoot ??= this.createRenderRoot();
		this.enableUpdating(true);
		this.__controllers?.forEach((c) => c.hostConnected?.());
	}
	/**
	* Note, this method should be considered final and not overridden. It is
	* overridden on the element instance with a function that triggers the first
	* update.
	* @category updates
	*/
	enableUpdating(_requestedUpdate) {}
	/**
	* Allows for `super.disconnectedCallback()` in extensions while
	* reserving the possibility of making non-breaking feature additions
	* when disconnecting at some point in the future.
	* @category lifecycle
	*/
	disconnectedCallback() {
		this.__controllers?.forEach((c) => c.hostDisconnected?.());
	}
	/**
	* Synchronizes property values when attributes change.
	*
	* Specifically, when an attribute is set, the corresponding property is set.
	* You should rarely need to implement this callback. If this method is
	* overridden, `super.attributeChangedCallback(name, _old, value)` must be
	* called.
	*
	* See [responding to attribute changes](https://developer.mozilla.org/en-US/docs/Web/API/Web_components/Using_custom_elements#responding_to_attribute_changes)
	* on MDN for more information about the `attributeChangedCallback`.
	* @category attributes
	*/
	attributeChangedCallback(name, _old, value) {
		this._$attributeToProperty(name, value);
	}
	__propertyToAttribute(name, value) {
		const options = this.constructor.elementProperties.get(name);
		const attr = this.constructor.__attributeNameForProperty(name, options);
		if (attr !== void 0 && options.reflect === true) {
			const attrValue = (options.converter?.toAttribute !== void 0 ? options.converter : defaultConverter).toAttribute(value, options.type);
			if (this.constructor.enabledWarnings.includes("migration") && attrValue === void 0) issueWarning$4("undefined-attribute-value", `The attribute value for the ${name} property is undefined on element ${this.localName}. The attribute will be removed, but in the previous version of \`ReactiveElement\`, the attribute would not have changed.`);
			this.__reflectingProperty = name;
			if (attrValue == null) this.removeAttribute(attr);
			else this.setAttribute(attr, attrValue);
			this.__reflectingProperty = null;
		}
	}
	/** @internal */
	_$attributeToProperty(name, value) {
		const ctor = this.constructor;
		const propName = ctor.__attributeToPropertyMap.get(name);
		if (propName !== void 0 && this.__reflectingProperty !== propName) {
			const options = ctor.getPropertyOptions(propName);
			const converter = typeof options.converter === "function" ? { fromAttribute: options.converter } : options.converter?.fromAttribute !== void 0 ? options.converter : defaultConverter;
			this.__reflectingProperty = propName;
			const convertedValue = converter.fromAttribute(value, options.type);
			this[propName] = convertedValue ?? this.__defaultValues?.get(propName) ?? convertedValue;
			this.__reflectingProperty = null;
		}
	}
	/**
	* Requests an update which is processed asynchronously. This should be called
	* when an element should update based on some state not triggered by setting
	* a reactive property. In this case, pass no arguments. It should also be
	* called when manually implementing a property setter. In this case, pass the
	* property `name` and `oldValue` to ensure that any configured property
	* options are honored.
	*
	* @param name name of requesting property
	* @param oldValue old value of requesting property
	* @param options property options to use instead of the previously
	*     configured options
	* @param useNewValue if true, the newValue argument is used instead of
	*     reading the property value. This is important to use if the reactive
	*     property is a standard private accessor, as opposed to a plain
	*     property, since private members can't be dynamically read by name.
	* @param newValue the new value of the property. This is only used if
	*     `useNewValue` is true.
	* @category updates
	*/
	requestUpdate(name, oldValue, options, useNewValue = false, newValue) {
		if (name !== void 0) {
			if (name instanceof Event) issueWarning$4(``, `The requestUpdate() method was called with an Event as the property name. This is probably a mistake caused by binding this.requestUpdate as an event listener. Instead bind a function that will call it with no arguments: () => this.requestUpdate()`);
			const ctor = this.constructor;
			if (useNewValue === false) newValue = this[name];
			options ??= ctor.getPropertyOptions(name);
			if ((options.hasChanged ?? notEqual)(newValue, oldValue) || options.useDefault && options.reflect && newValue === this.__defaultValues?.get(name) && !this.hasAttribute(ctor.__attributeNameForProperty(name, options))) this._$changeProperty(name, oldValue, options);
			else return;
		}
		if (this.isUpdatePending === false) this.__updatePromise = this.__enqueueUpdate();
	}
	/**
	* @internal
	*/
	_$changeProperty(name, oldValue, { useDefault, reflect, wrapped }, initializeValue) {
		if (useDefault && !(this.__defaultValues ??= /* @__PURE__ */ new Map()).has(name)) {
			this.__defaultValues.set(name, initializeValue ?? oldValue ?? this[name]);
			if (wrapped !== true || initializeValue !== void 0) return;
		}
		if (!this._$changedProperties.has(name)) {
			if (!this.hasUpdated && !useDefault) oldValue = void 0;
			this._$changedProperties.set(name, oldValue);
		}
		if (reflect === true && this.__reflectingProperty !== name) (this.__reflectingProperties ??= /* @__PURE__ */ new Set()).add(name);
	}
	/**
	* Sets up the element to asynchronously update.
	*/
	async __enqueueUpdate() {
		this.isUpdatePending = true;
		try {
			await this.__updatePromise;
		} catch (e) {
			Promise.reject(e);
		}
		const result = this.scheduleUpdate();
		if (result != null) await result;
		return !this.isUpdatePending;
	}
	/**
	* Schedules an element update. You can override this method to change the
	* timing of updates by returning a Promise. The update will await the
	* returned Promise, and you should resolve the Promise to allow the update
	* to proceed. If this method is overridden, `super.scheduleUpdate()`
	* must be called.
	*
	* For instance, to schedule updates to occur just before the next frame:
	*
	* ```ts
	* override protected async scheduleUpdate(): Promise<unknown> {
	*   await new Promise((resolve) => requestAnimationFrame(() => resolve()));
	*   super.scheduleUpdate();
	* }
	* ```
	* @category updates
	*/
	scheduleUpdate() {
		const result = this.performUpdate();
		if (this.constructor.enabledWarnings.includes("async-perform-update") && typeof result?.then === "function") issueWarning$4("async-perform-update", `Element ${this.localName} returned a Promise from performUpdate(). This behavior is deprecated and will be removed in a future version of ReactiveElement.`);
		return result;
	}
	/**
	* Performs an element update. Note, if an exception is thrown during the
	* update, `firstUpdated` and `updated` will not be called.
	*
	* Call `performUpdate()` to immediately process a pending update. This should
	* generally not be needed, but it can be done in rare cases when you need to
	* update synchronously.
	*
	* @category updates
	*/
	performUpdate() {
		if (!this.isUpdatePending) return;
		debugLogEvent$1?.({ kind: "update" });
		if (!this.hasUpdated) {
			this.renderRoot ??= this.createRenderRoot();
			{
				const shadowedProperties = [...this.constructor.elementProperties.keys()].filter((p) => this.hasOwnProperty(p) && p in getPrototypeOf(this));
				if (shadowedProperties.length) throw new Error(`The following properties on element ${this.localName} will not trigger updates as expected because they are set using class fields: ${shadowedProperties.join(", ")}. Native class fields and some compiled output will overwrite accessors used for detecting changes. See https://lit.dev/msg/class-field-shadowing for more information.`);
			}
			if (this.__instanceProperties) {
				for (const [p, value] of this.__instanceProperties) this[p] = value;
				this.__instanceProperties = void 0;
			}
			const elementProperties = this.constructor.elementProperties;
			if (elementProperties.size > 0) for (const [p, options] of elementProperties) {
				const { wrapped } = options;
				const value = this[p];
				if (wrapped === true && !this._$changedProperties.has(p) && value !== void 0) this._$changeProperty(p, void 0, options, value);
			}
		}
		let shouldUpdate = false;
		const changedProperties = this._$changedProperties;
		try {
			shouldUpdate = this.shouldUpdate(changedProperties);
			if (shouldUpdate) {
				this.willUpdate(changedProperties);
				this.__controllers?.forEach((c) => c.hostUpdate?.());
				this.update(changedProperties);
			} else this.__markUpdated();
		} catch (e) {
			shouldUpdate = false;
			this.__markUpdated();
			throw e;
		}
		if (shouldUpdate) this._$didUpdate(changedProperties);
	}
	/**
	* Invoked before `update()` to compute values needed during the update.
	*
	* Implement `willUpdate` to compute property values that depend on other
	* properties and are used in the rest of the update process.
	*
	* ```ts
	* willUpdate(changedProperties) {
	*   // only need to check changed properties for an expensive computation.
	*   if (changedProperties.has('firstName') || changedProperties.has('lastName')) {
	*     this.sha = computeSHA(`${this.firstName} ${this.lastName}`);
	*   }
	* }
	*
	* render() {
	*   return html`SHA: ${this.sha}`;
	* }
	* ```
	*
	* @category updates
	*/
	willUpdate(_changedProperties) {}
	_$didUpdate(changedProperties) {
		this.__controllers?.forEach((c) => c.hostUpdated?.());
		if (!this.hasUpdated) {
			this.hasUpdated = true;
			this.firstUpdated(changedProperties);
		}
		this.updated(changedProperties);
		if (this.isUpdatePending && this.constructor.enabledWarnings.includes("change-in-update")) issueWarning$4("change-in-update", `Element ${this.localName} scheduled an update (generally because a property was set) after an update completed, causing a new update to be scheduled. This is inefficient and should be avoided unless the next update can only be scheduled as a side effect of the previous update.`);
	}
	__markUpdated() {
		this._$changedProperties = /* @__PURE__ */ new Map();
		this.isUpdatePending = false;
	}
	/**
	* Returns a Promise that resolves when the element has completed updating.
	* The Promise value is a boolean that is `true` if the element completed the
	* update without triggering another update. The Promise result is `false` if
	* a property was set inside `updated()`. If the Promise is rejected, an
	* exception was thrown during the update.
	*
	* To await additional asynchronous work, override the `getUpdateComplete`
	* method. For example, it is sometimes useful to await a rendered element
	* before fulfilling this Promise. To do this, first await
	* `super.getUpdateComplete()`, then any subsequent state.
	*
	* @return A promise of a boolean that resolves to true if the update completed
	*     without triggering another update.
	* @category updates
	*/
	get updateComplete() {
		return this.getUpdateComplete();
	}
	/**
	* Override point for the `updateComplete` promise.
	*
	* It is not safe to override the `updateComplete` getter directly due to a
	* limitation in TypeScript which means it is not possible to call a
	* superclass getter (e.g. `super.updateComplete.then(...)`) when the target
	* language is ES5 (https://github.com/microsoft/TypeScript/issues/338).
	* This method should be overridden instead. For example:
	*
	* ```ts
	* class MyElement extends LitElement {
	*   override async getUpdateComplete() {
	*     const result = await super.getUpdateComplete();
	*     await this._myChild.updateComplete;
	*     return result;
	*   }
	* }
	* ```
	*
	* @return A promise of a boolean that resolves to true if the update completed
	*     without triggering another update.
	* @category updates
	*/
	getUpdateComplete() {
		return this.__updatePromise;
	}
	/**
	* Controls whether or not `update()` should be called when the element requests
	* an update. By default, this method always returns `true`, but this can be
	* customized to control when to update.
	*
	* @param _changedProperties Map of changed properties with old values
	* @category updates
	*/
	shouldUpdate(_changedProperties) {
		return true;
	}
	/**
	* Updates the element. This method reflects property values to attributes.
	* It can be overridden to render and keep updated element DOM.
	* Setting properties inside this method will *not* trigger
	* another update.
	*
	* @param _changedProperties Map of changed properties with old values
	* @category updates
	*/
	update(_changedProperties) {
		this.__reflectingProperties &&= this.__reflectingProperties.forEach((p) => this.__propertyToAttribute(p, this[p]));
		this.__markUpdated();
	}
	/**
	* Invoked whenever the element is updated. Implement to perform
	* post-updating tasks via DOM APIs, for example, focusing an element.
	*
	* Setting properties inside this method will trigger the element to update
	* again after this update cycle completes.
	*
	* @param _changedProperties Map of changed properties with old values
	* @category updates
	*/
	updated(_changedProperties) {}
	/**
	* Invoked when the element is first updated. Implement to perform one time
	* work on the element after update.
	*
	* ```ts
	* firstUpdated() {
	*   this.renderRoot.getElementById('my-text-area').focus();
	* }
	* ```
	*
	* Setting properties inside this method will trigger the element to update
	* again after this update cycle completes.
	*
	* @param _changedProperties Map of changed properties with old values
	* @category updates
	*/
	firstUpdated(_changedProperties) {}
};
/**
* Memoized list of all element styles.
* Created lazily on user subclasses when finalizing the class.
* @nocollapse
* @category styles
*/
ReactiveElement.elementStyles = [];
/**
* Options used when calling `attachShadow`. Set this property to customize
* the options for the shadowRoot; for example, to create a closed
* shadowRoot: `{mode: 'closed'}`.
*
* Note, these options are used in `createRenderRoot`. If this method
* is customized, options should be respected if possible.
* @nocollapse
* @category rendering
*/
ReactiveElement.shadowRootOptions = { mode: "open" };
ReactiveElement[JSCompiler_renameProperty$1("elementProperties", ReactiveElement)] = /* @__PURE__ */ new Map();
ReactiveElement[JSCompiler_renameProperty$1("finalized", ReactiveElement)] = /* @__PURE__ */ new Map();
polyfillSupport$2?.({ ReactiveElement });
{
	ReactiveElement.enabledWarnings = ["change-in-update", "async-perform-update"];
	const ensureOwnWarnings = function(ctor) {
		if (!ctor.hasOwnProperty(JSCompiler_renameProperty$1("enabledWarnings", ctor))) ctor.enabledWarnings = ctor.enabledWarnings.slice();
	};
	ReactiveElement.enableWarning = function(warning) {
		ensureOwnWarnings(this);
		if (!this.enabledWarnings.includes(warning)) this.enabledWarnings.push(warning);
	};
	ReactiveElement.disableWarning = function(warning) {
		ensureOwnWarnings(this);
		const i = this.enabledWarnings.indexOf(warning);
		if (i >= 0) this.enabledWarnings.splice(i, 1);
	};
}
(global$2.reactiveElementVersions ??= []).push("2.1.2");
if (global$2.reactiveElementVersions.length > 1) queueMicrotask(() => {
	issueWarning$4("multiple-versions", "Multiple versions of Lit loaded. Loading multiple versions is not recommended.");
});
// node_modules/lit-html/development/lit-html.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
var global$1 = globalThis;
/**
* Useful for visualizing and logging insights into what the Lit template system is doing.
*
* Compiled out of prod mode builds.
*/
var debugLogEvent = (event) => {
	if (!global$1.emitLitDebugLogEvents) return;
	global$1.dispatchEvent(new CustomEvent("lit-debug", { detail: event }));
};
var debugLogRenderId = 0;
var issueWarning$3;
global$1.litIssuedWarnings ??= /* @__PURE__ */ new Set();
/**
* Issue a warning if we haven't already, based either on `code` or `warning`.
* Warnings are disabled automatically only by `warning`; disabling via `code`
* can be done by users.
*/
issueWarning$3 = (code, warning) => {
	warning += code ? ` See https://lit.dev/msg/${code} for more information.` : "";
	if (!global$1.litIssuedWarnings.has(warning) && !global$1.litIssuedWarnings.has(code)) {
		console.warn(warning);
		global$1.litIssuedWarnings.add(warning);
	}
};
queueMicrotask(() => {
	issueWarning$3("dev-mode", `Lit is in dev mode. Not recommended for production!`);
});
var wrap = global$1.ShadyDOM?.inUse && global$1.ShadyDOM?.noPatch === true ? global$1.ShadyDOM.wrap : (node) => node;
var trustedTypes = global$1.trustedTypes;
/**
* Our TrustedTypePolicy for HTML which is declared using the html template
* tag function.
*
* That HTML is a developer-authored constant, and is parsed with innerHTML
* before any untrusted expressions have been mixed in. Therefor it is
* considered safe by construction.
*/
var policy = trustedTypes ? trustedTypes.createPolicy("lit-html", { createHTML: (s) => s }) : void 0;
var identityFunction = (value) => value;
var noopSanitizer = (_node, _name, _type) => identityFunction;
/** Sets the global sanitizer factory. */
var setSanitizer = (newSanitizer) => {
	if (sanitizerFactoryInternal !== noopSanitizer) throw new Error("Attempted to overwrite existing lit-html security policy. setSanitizeDOMValueFactory should be called at most once.");
	sanitizerFactoryInternal = newSanitizer;
};
/**
* Only used in internal tests, not a part of the public API.
*/
var _testOnlyClearSanitizerFactoryDoNotCallOrElse = () => {
	sanitizerFactoryInternal = noopSanitizer;
};
var createSanitizer = (node, name, type) => {
	return sanitizerFactoryInternal(node, name, type);
};
var boundAttributeSuffix = "$lit$";
var marker = `lit$${Math.random().toFixed(9).slice(2)}$`;
var markerMatch = "?" + marker;
var nodeMarker = `<${markerMatch}>`;
var d = document;
var createMarker = () => d.createComment("");
var isPrimitive = (value) => value === null || typeof value != "object" && typeof value != "function";
var isArray = Array.isArray;
var isIterable = (value) => isArray(value) || typeof value?.[Symbol.iterator] === "function";
var SPACE_CHAR = `[ \t\n\f\r]`;
var ATTR_VALUE_CHAR = `[^ \t\n\f\r"'\`<>=]`;
var NAME_CHAR = `[^\\s"'>=/]`;
/**
* End of text is: `<` followed by:
*   (comment start) or (tag) or (dynamic tag binding)
*/
var textEndRegex = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g;
var COMMENT_START = 1;
var TAG_NAME = 2;
var DYNAMIC_TAG_NAME = 3;
var commentEndRegex = /-->/g;
/**
* Comments not started with <!--, like </{, can be ended by a single `>`
*/
var comment2EndRegex = />/g;
/**
* The tagEnd regex matches the end of the "inside an opening" tag syntax
* position. It either matches a `>`, an attribute-like sequence, or the end
* of the string after a space (attribute-name position ending).
*
* See attributes in the HTML spec:
* https://www.w3.org/TR/html5/syntax.html#elements-attributes
*
* " \t\n\f\r" are HTML space characters:
* https://infra.spec.whatwg.org/#ascii-whitespace
*
* So an attribute is:
*  * The name: any character except a whitespace character, ("), ('), ">",
*    "=", or "/". Note: this is different from the HTML spec which also excludes control characters.
*  * Followed by zero or more space characters
*  * Followed by "="
*  * Followed by zero or more space characters
*  * Followed by:
*    * Any character except space, ('), ("), "<", ">", "=", (`), or
*    * (") then any non-("), or
*    * (') then any non-(')
*/
var tagEndRegex = new RegExp(`>|${SPACE_CHAR}(?:(${NAME_CHAR}+)(${SPACE_CHAR}*=${SPACE_CHAR}*(?:${ATTR_VALUE_CHAR}|("|')|))|$)`, "g");
var ENTIRE_MATCH = 0;
var ATTRIBUTE_NAME = 1;
var SPACES_AND_EQUALS = 2;
var QUOTE_CHAR = 3;
var singleQuoteAttrEndRegex = /'/g;
var doubleQuoteAttrEndRegex = /"/g;
/**
* Matches the raw text elements.
*
* Comments are not parsed within raw text elements, so we need to search their
* text content for marker strings.
*/
var rawTextElement = /^(?:script|style|textarea|title)$/i;
/** TemplateResult types */
var HTML_RESULT = 1;
var SVG_RESULT = 2;
var MATHML_RESULT = 3;
var ATTRIBUTE_PART = 1;
var CHILD_PART = 2;
var PROPERTY_PART = 3;
var BOOLEAN_ATTRIBUTE_PART = 4;
var EVENT_PART = 5;
var ELEMENT_PART = 6;
var COMMENT_PART = 7;
/**
* Generates a template literal tag function that returns a TemplateResult with
* the given result type.
*/
var tag = (type) => (strings, ...values) => {
	if (strings.some((s) => s === void 0)) console.warn("Some template strings are undefined.\nThis is probably caused by illegal octal escape sequences.");
	if (values.some((val) => val?.["_$litStatic$"])) issueWarning$3("", "Static values 'literal' or 'unsafeStatic' cannot be used as values to non-static templates.\nPlease use the static 'html' tag function. See https://lit.dev/docs/templates/expressions/#static-expressions");
	return {
		["_$litType$"]: type,
		strings,
		values
	};
};
/**
* Interprets a template literal as an HTML template that can efficiently
* render to and update a container.
*
* ```ts
* const header = (title: string) => html`<h1>${title}</h1>`;
* ```
*
* The `html` tag returns a description of the DOM to render as a value. It is
* lazy, meaning no work is done until the template is rendered. When rendering,
* if a template comes from the same expression as a previously rendered result,
* it's efficiently updated instead of replaced.
*/
var html = tag(HTML_RESULT);
/**
* Interprets a template literal as an SVG fragment that can efficiently render
* to and update a container.
*
* ```ts
* const rect = svg`<rect width="10" height="10"></rect>`;
*
* const myImage = html`
*   <svg viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg">
*     ${rect}
*   </svg>`;
* ```
*
* The `svg` *tag function* should only be used for SVG fragments, or elements
* that would be contained **inside** an `<svg>` HTML element. A common error is
* placing an `<svg>` *element* in a template tagged with the `svg` tag
* function. The `<svg>` element is an HTML element and should be used within a
* template tagged with the {@linkcode html} tag function.
*
* In LitElement usage, it's invalid to return an SVG fragment from the
* `render()` method, as the SVG fragment will be contained within the element's
* shadow root and thus not be properly contained within an `<svg>` HTML
* element.
*/
var svg = tag(SVG_RESULT);
/**
* Interprets a template literal as MathML fragment that can efficiently render
* to and update a container.
*
* ```ts
* const num = mathml`<mn>1</mn>`;
*
* const eq = html`
*   <math>
*     ${num}
*   </math>`;
* ```
*
* The `mathml` *tag function* should only be used for MathML fragments, or
* elements that would be contained **inside** a `<math>` HTML element. A common
* error is placing a `<math>` *element* in a template tagged with the `mathml`
* tag function. The `<math>` element is an HTML element and should be used
* within a template tagged with the {@linkcode html} tag function.
*
* In LitElement usage, it's invalid to return an MathML fragment from the
* `render()` method, as the MathML fragment will be contained within the
* element's shadow root and thus not be properly contained within a `<math>`
* HTML element.
*/
var mathml = tag(MATHML_RESULT);
/**
* A sentinel value that signals that a value was handled by a directive and
* should not be written to the DOM.
*/
var noChange = Symbol.for("lit-noChange");
/**
* A sentinel value that signals a ChildPart to fully clear its content.
*
* ```ts
* const button = html`${
*  user.isAdmin
*    ? html`<button>DELETE</button>`
*    : nothing
* }`;
* ```
*
* Prefer using `nothing` over other falsy values as it provides a consistent
* behavior between various expression binding contexts.
*
* In child expressions, `undefined`, `null`, `''`, and `nothing` all behave the
* same and render no nodes. In attribute expressions, `nothing` _removes_ the
* attribute, while `undefined` and `null` will render an empty string. In
* property expressions `nothing` becomes `undefined`.
*/
var nothing = Symbol.for("lit-nothing");
/**
* The cache of prepared templates, keyed by the tagged TemplateStringsArray
* and _not_ accounting for the specific template tag used. This means that
* template tags cannot be dynamic - they must statically be one of html, svg,
* or attr. This restriction simplifies the cache lookup, which is on the hot
* path for rendering.
*/
var templateCache = /* @__PURE__ */ new WeakMap();
var walker = d.createTreeWalker(d, 129);
var sanitizerFactoryInternal = noopSanitizer;
function trustFromTemplateString(tsa, stringFromTSA) {
	if (!isArray(tsa) || !tsa.hasOwnProperty("raw")) {
		let message = "invalid template strings array";
		message = `
          Internal Error: expected template strings to be an array
          with a 'raw' field. Faking a template strings array by
          calling html or svg like an ordinary function is effectively
          the same as calling unsafeHtml and can lead to major security
          issues, e.g. opening your code up to XSS attacks.
          If you're using the html or svg tagged template functions normally
          and still seeing this error, please file a bug at
          https://github.com/lit/lit/issues/new?template=bug_report.md
          and include information about your build tooling, if any.
        `.trim().replace(/\n */g, "\n");
		throw new Error(message);
	}
	return policy !== void 0 ? policy.createHTML(stringFromTSA) : stringFromTSA;
}
/**
* Returns an HTML string for the given TemplateStringsArray and result type
* (HTML or SVG), along with the case-sensitive bound attribute names in
* template order. The HTML contains comment markers denoting the `ChildPart`s
* and suffixes on bound attributes denoting the `AttributeParts`.
*
* @param strings template strings array
* @param type HTML or SVG
* @return Array containing `[html, attrNames]` (array returned for terseness,
*     to avoid object fields since this code is shared with non-minified SSR
*     code)
*/
var getTemplateHtml = (strings, type) => {
	const l = strings.length - 1;
	const attrNames = [];
	let html = type === SVG_RESULT ? "<svg>" : type === MATHML_RESULT ? "<math>" : "";
	let rawTextEndRegex;
	let regex = textEndRegex;
	for (let i = 0; i < l; i++) {
		const s = strings[i];
		let attrNameEndIndex = -1;
		let attrName;
		let lastIndex = 0;
		let match;
		while (lastIndex < s.length) {
			regex.lastIndex = lastIndex;
			match = regex.exec(s);
			if (match === null) break;
			lastIndex = regex.lastIndex;
			if (regex === textEndRegex) {
				if (match[COMMENT_START] === "!--") regex = commentEndRegex;
				else if (match[COMMENT_START] !== void 0) regex = comment2EndRegex;
				else if (match[TAG_NAME] !== void 0) {
					if (rawTextElement.test(match[TAG_NAME])) rawTextEndRegex = new RegExp(`</${match[TAG_NAME]}`, "g");
					regex = tagEndRegex;
				} else if (match[DYNAMIC_TAG_NAME] !== void 0) throw new Error("Bindings in tag names are not supported. Please use static templates instead. See https://lit.dev/docs/templates/expressions/#static-expressions");
			} else if (regex === tagEndRegex) {
				if (match[ENTIRE_MATCH] === ">") {
					regex = rawTextEndRegex ?? textEndRegex;
					attrNameEndIndex = -1;
				} else if (match[ATTRIBUTE_NAME] === void 0) attrNameEndIndex = -2;
				else {
					attrNameEndIndex = regex.lastIndex - match[SPACES_AND_EQUALS].length;
					attrName = match[ATTRIBUTE_NAME];
					regex = match[QUOTE_CHAR] === void 0 ? tagEndRegex : match[QUOTE_CHAR] === "\"" ? doubleQuoteAttrEndRegex : singleQuoteAttrEndRegex;
				}
			} else if (regex === doubleQuoteAttrEndRegex || regex === singleQuoteAttrEndRegex) regex = tagEndRegex;
			else if (regex === commentEndRegex || regex === comment2EndRegex) regex = textEndRegex;
			else {
				regex = tagEndRegex;
				rawTextEndRegex = void 0;
			}
		}
		console.assert(attrNameEndIndex === -1 || regex === tagEndRegex || regex === singleQuoteAttrEndRegex || regex === doubleQuoteAttrEndRegex, "unexpected parse state B");
		const end = regex === tagEndRegex && strings[i + 1].startsWith("/>") ? " " : "";
		html += regex === textEndRegex ? s + nodeMarker : attrNameEndIndex >= 0 ? (attrNames.push(attrName), s.slice(0, attrNameEndIndex) + boundAttributeSuffix + s.slice(attrNameEndIndex)) + marker + end : s + marker + (attrNameEndIndex === -2 ? i : end);
	}
	return [trustFromTemplateString(strings, html + (strings[l] || "<?>") + (type === SVG_RESULT ? "</svg>" : type === MATHML_RESULT ? "</math>" : "")), attrNames];
};
var Template = class Template {
	constructor({ strings, ["_$litType$"]: type }, options) {
		this.parts = [];
		let node;
		let nodeIndex = 0;
		let attrNameIndex = 0;
		const partCount = strings.length - 1;
		const parts = this.parts;
		const [html, attrNames] = getTemplateHtml(strings, type);
		this.el = Template.createElement(html, options);
		walker.currentNode = this.el.content;
		if (type === SVG_RESULT || type === MATHML_RESULT) {
			const wrapper = this.el.content.firstChild;
			wrapper.replaceWith(...wrapper.childNodes);
		}
		while ((node = walker.nextNode()) !== null && parts.length < partCount) {
			if (node.nodeType === 1) {
				{
					const tag = node.localName;
					if (/^(?:textarea|template)$/i.test(tag) && node.innerHTML.includes(marker)) {
						const m = `Expressions are not supported inside \`${tag}\` elements. See https://lit.dev/msg/expression-in-${tag} for more information.`;
						if (tag === "template") throw new Error(m);
						else issueWarning$3("", m);
					}
				}
				if (node.hasAttributes()) {
					for (const name of node.getAttributeNames()) if (name.endsWith(boundAttributeSuffix)) {
						const realName = attrNames[attrNameIndex++];
						const statics = node.getAttribute(name).split(marker);
						const m = /([.?@])?(.*)/.exec(realName);
						parts.push({
							type: ATTRIBUTE_PART,
							index: nodeIndex,
							name: m[2],
							strings: statics,
							ctor: m[1] === "." ? PropertyPart : m[1] === "?" ? BooleanAttributePart : m[1] === "@" ? EventPart : AttributePart
						});
						node.removeAttribute(name);
					} else if (name.startsWith(marker)) {
						parts.push({
							type: ELEMENT_PART,
							index: nodeIndex
						});
						node.removeAttribute(name);
					}
				}
				if (rawTextElement.test(node.tagName)) {
					const strings = node.textContent.split(marker);
					const lastIndex = strings.length - 1;
					if (lastIndex > 0) {
						node.textContent = trustedTypes ? trustedTypes.emptyScript : "";
						for (let i = 0; i < lastIndex; i++) {
							node.append(strings[i], createMarker());
							walker.nextNode();
							parts.push({
								type: CHILD_PART,
								index: ++nodeIndex
							});
						}
						node.append(strings[lastIndex], createMarker());
					}
				}
			} else if (node.nodeType === 8) {
				if (node.data === markerMatch) parts.push({
					type: CHILD_PART,
					index: nodeIndex
				});
				else {
					let i = -1;
					while ((i = node.data.indexOf(marker, i + 1)) !== -1) {
						parts.push({
							type: COMMENT_PART,
							index: nodeIndex
						});
						i += marker.length - 1;
					}
				}
			}
			nodeIndex++;
		}
		if (attrNames.length !== attrNameIndex) throw new Error("Detected duplicate attribute bindings. This occurs if your template has duplicate attributes on an element tag. For example \"<input ?disabled=${true} ?disabled=${false}>\" contains a duplicate \"disabled\" attribute. The error was detected in the following template: \n`" + strings.join("${...}") + "`");
		debugLogEvent && debugLogEvent({
			kind: "template prep",
			template: this,
			clonableTemplate: this.el,
			parts: this.parts,
			strings
		});
	}
	/** @nocollapse */
	static createElement(html, _options) {
		const el = d.createElement("template");
		el.innerHTML = html;
		return el;
	}
};
function resolveDirective(part, value, parent = part, attributeIndex) {
	if (value === noChange) return value;
	let currentDirective = attributeIndex !== void 0 ? parent.__directives?.[attributeIndex] : parent.__directive;
	const nextDirectiveConstructor = isPrimitive(value) ? void 0 : value["_$litDirective$"];
	if (currentDirective?.constructor !== nextDirectiveConstructor) {
		currentDirective?.["_$notifyDirectiveConnectionChanged"]?.(false);
		if (nextDirectiveConstructor === void 0) currentDirective = void 0;
		else {
			currentDirective = new nextDirectiveConstructor(part);
			currentDirective._$initialize(part, parent, attributeIndex);
		}
		if (attributeIndex !== void 0) (parent.__directives ??= [])[attributeIndex] = currentDirective;
		else parent.__directive = currentDirective;
	}
	if (currentDirective !== void 0) value = resolveDirective(part, currentDirective._$resolve(part, value.values), currentDirective, attributeIndex);
	return value;
}
/**
* An updateable instance of a Template. Holds references to the Parts used to
* update the template instance.
*/
var TemplateInstance = class {
	constructor(template, parent) {
		this._$parts = [];
		/** @internal */
		this._$disconnectableChildren = void 0;
		this._$template = template;
		this._$parent = parent;
	}
	get parentNode() {
		return this._$parent.parentNode;
	}
	get _$isConnected() {
		return this._$parent._$isConnected;
	}
	_clone(options) {
		const { el: { content }, parts } = this._$template;
		const fragment = (options?.creationScope ?? d).importNode(content, true);
		walker.currentNode = fragment;
		let node = walker.nextNode();
		let nodeIndex = 0;
		let partIndex = 0;
		let templatePart = parts[0];
		while (templatePart !== void 0) {
			if (nodeIndex === templatePart.index) {
				let part;
				if (templatePart.type === CHILD_PART) part = new ChildPart(node, node.nextSibling, this, options);
				else if (templatePart.type === ATTRIBUTE_PART) part = new templatePart.ctor(node, templatePart.name, templatePart.strings, this, options);
				else if (templatePart.type === ELEMENT_PART) part = new ElementPart(node, this, options);
				this._$parts.push(part);
				templatePart = parts[++partIndex];
			}
			if (nodeIndex !== templatePart?.index) {
				node = walker.nextNode();
				nodeIndex++;
			}
		}
		walker.currentNode = d;
		return fragment;
	}
	_update(values) {
		let i = 0;
		for (const part of this._$parts) {
			if (part !== void 0) {
				debugLogEvent && debugLogEvent({
					kind: "set part",
					part,
					value: values[i],
					valueIndex: i,
					values,
					templateInstance: this
				});
				if (part.strings !== void 0) {
					part._$setValue(values, part, i);
					i += part.strings.length - 2;
				} else part._$setValue(values[i]);
			}
			i++;
		}
	}
};
var ChildPart = class ChildPart {
	get _$isConnected() {
		return this._$parent?._$isConnected ?? this.__isConnected;
	}
	constructor(startNode, endNode, parent, options) {
		this.type = CHILD_PART;
		this._$committedValue = nothing;
		/** @internal */
		this._$disconnectableChildren = void 0;
		this._$startNode = startNode;
		this._$endNode = endNode;
		this._$parent = parent;
		this.options = options;
		this.__isConnected = options?.isConnected ?? true;
		this._textSanitizer = void 0;
	}
	/**
	* The parent node into which the part renders its content.
	*
	* A ChildPart's content consists of a range of adjacent child nodes of
	* `.parentNode`, possibly bordered by 'marker nodes' (`.startNode` and
	* `.endNode`).
	*
	* - If both `.startNode` and `.endNode` are non-null, then the part's content
	* consists of all siblings between `.startNode` and `.endNode`, exclusively.
	*
	* - If `.startNode` is non-null but `.endNode` is null, then the part's
	* content consists of all siblings following `.startNode`, up to and
	* including the last child of `.parentNode`. If `.endNode` is non-null, then
	* `.startNode` will always be non-null.
	*
	* - If both `.endNode` and `.startNode` are null, then the part's content
	* consists of all child nodes of `.parentNode`.
	*/
	get parentNode() {
		let parentNode = wrap(this._$startNode).parentNode;
		const parent = this._$parent;
		if (parent !== void 0 && parentNode?.nodeType === 11) parentNode = parent.parentNode;
		return parentNode;
	}
	/**
	* The part's leading marker node, if any. See `.parentNode` for more
	* information.
	*/
	get startNode() {
		return this._$startNode;
	}
	/**
	* The part's trailing marker node, if any. See `.parentNode` for more
	* information.
	*/
	get endNode() {
		return this._$endNode;
	}
	_$setValue(value, directiveParent = this) {
		if (this.parentNode === null) throw new Error(`This \`ChildPart\` has no \`parentNode\` and therefore cannot accept a value. This likely means the element containing the part was manipulated in an unsupported way outside of Lit's control such that the part's marker nodes were ejected from DOM. For example, setting the element's \`innerHTML\` or \`textContent\` can do this.`);
		value = resolveDirective(this, value, directiveParent);
		if (isPrimitive(value)) {
			if (value === nothing || value == null || value === "") {
				if (this._$committedValue !== nothing) {
					debugLogEvent && debugLogEvent({
						kind: "commit nothing to child",
						start: this._$startNode,
						end: this._$endNode,
						parent: this._$parent,
						options: this.options
					});
					this._$clear();
				}
				this._$committedValue = nothing;
			} else if (value !== this._$committedValue && value !== noChange) this._commitText(value);
		} else if (value["_$litType$"] !== void 0) this._commitTemplateResult(value);
		else if (value.nodeType !== void 0) {
			if (this.options?.host === value) {
				this._commitText("[probable mistake: rendered a template's host in itself (commonly caused by writing ${this} in a template]");
				console.warn(`Attempted to render the template host`, value, `inside itself. This is almost always a mistake, and in dev mode `, `we render some warning text. In production however, we'll `, `render it, which will usually result in an error, and sometimes `, `in the element disappearing from the DOM.`);
				return;
			}
			this._commitNode(value);
		} else if (isIterable(value)) this._commitIterable(value);
		else this._commitText(value);
	}
	_insert(node) {
		return wrap(wrap(this._$startNode).parentNode).insertBefore(node, this._$endNode);
	}
	_commitNode(value) {
		if (this._$committedValue !== value) {
			this._$clear();
			if (sanitizerFactoryInternal !== noopSanitizer) {
				const parentNodeName = this._$startNode.parentNode?.nodeName;
				if (parentNodeName === "STYLE" || parentNodeName === "SCRIPT") {
					let message = "Forbidden";
					if (parentNodeName === "STYLE") message = "Lit does not support binding inside style nodes. This is a security risk, as style injection attacks can exfiltrate data and spoof UIs. Consider instead using css`...` literals to compose styles, and do dynamic styling with css custom properties, ::parts, <slot>s, and by mutating the DOM rather than stylesheets.";
					else message = "Lit does not support binding inside script nodes. This is a security risk, as it could allow arbitrary code execution.";
					throw new Error(message);
				}
			}
			debugLogEvent && debugLogEvent({
				kind: "commit node",
				start: this._$startNode,
				parent: this._$parent,
				value,
				options: this.options
			});
			this._$committedValue = this._insert(value);
		}
	}
	_commitText(value) {
		if (this._$committedValue !== nothing && isPrimitive(this._$committedValue)) {
			const node = wrap(this._$startNode).nextSibling;
			if (this._textSanitizer === void 0) this._textSanitizer = createSanitizer(node, "data", "property");
			value = this._textSanitizer(value);
			debugLogEvent && debugLogEvent({
				kind: "commit text",
				node,
				value,
				options: this.options
			});
			node.data = value;
		} else {
			const textNode = d.createTextNode("");
			this._commitNode(textNode);
			if (this._textSanitizer === void 0) this._textSanitizer = createSanitizer(textNode, "data", "property");
			value = this._textSanitizer(value);
			debugLogEvent && debugLogEvent({
				kind: "commit text",
				node: textNode,
				value,
				options: this.options
			});
			textNode.data = value;
		}
		this._$committedValue = value;
	}
	_commitTemplateResult(result) {
		const { values, ["_$litType$"]: type } = result;
		const template = typeof type === "number" ? this._$getTemplate(result) : (type.el === void 0 && (type.el = Template.createElement(trustFromTemplateString(type.h, type.h[0]), this.options)), type);
		if (this._$committedValue?._$template === template) {
			debugLogEvent && debugLogEvent({
				kind: "template updating",
				template,
				instance: this._$committedValue,
				parts: this._$committedValue._$parts,
				options: this.options,
				values
			});
			this._$committedValue._update(values);
		} else {
			const instance = new TemplateInstance(template, this);
			const fragment = instance._clone(this.options);
			debugLogEvent && debugLogEvent({
				kind: "template instantiated",
				template,
				instance,
				parts: instance._$parts,
				options: this.options,
				fragment,
				values
			});
			instance._update(values);
			debugLogEvent && debugLogEvent({
				kind: "template instantiated and updated",
				template,
				instance,
				parts: instance._$parts,
				options: this.options,
				fragment,
				values
			});
			this._commitNode(fragment);
			this._$committedValue = instance;
		}
	}
	/** @internal */
	_$getTemplate(result) {
		let template = templateCache.get(result.strings);
		if (template === void 0) templateCache.set(result.strings, template = new Template(result));
		return template;
	}
	_commitIterable(value) {
		if (!isArray(this._$committedValue)) {
			this._$committedValue = [];
			this._$clear();
		}
		const itemParts = this._$committedValue;
		let partIndex = 0;
		let itemPart;
		for (const item of value) {
			if (partIndex === itemParts.length) itemParts.push(itemPart = new ChildPart(this._insert(createMarker()), this._insert(createMarker()), this, this.options));
			else itemPart = itemParts[partIndex];
			itemPart._$setValue(item);
			partIndex++;
		}
		if (partIndex < itemParts.length) {
			this._$clear(itemPart && wrap(itemPart._$endNode).nextSibling, partIndex);
			itemParts.length = partIndex;
		}
	}
	/**
	* Removes the nodes contained within this Part from the DOM.
	*
	* @param start Start node to clear from, for clearing a subset of the part's
	*     DOM (used when truncating iterables)
	* @param from  When `start` is specified, the index within the iterable from
	*     which ChildParts are being removed, used for disconnecting directives
	*     in those Parts.
	*
	* @internal
	*/
	_$clear(start = wrap(this._$startNode).nextSibling, from) {
		this._$notifyConnectionChanged?.(false, true, from);
		while (start !== this._$endNode) {
			const n = wrap(start).nextSibling;
			wrap(start).remove();
			start = n;
		}
	}
	/**
	* Implementation of RootPart's `isConnected`. Note that this method
	* should only be called on `RootPart`s (the `ChildPart` returned from a
	* top-level `render()` call). It has no effect on non-root ChildParts.
	* @param isConnected Whether to set
	* @internal
	*/
	setConnected(isConnected) {
		if (this._$parent === void 0) {
			this.__isConnected = isConnected;
			this._$notifyConnectionChanged?.(isConnected);
		} else throw new Error("part.setConnected() may only be called on a RootPart returned from render().");
	}
};
var AttributePart = class {
	get tagName() {
		return this.element.tagName;
	}
	get _$isConnected() {
		return this._$parent._$isConnected;
	}
	constructor(element, name, strings, parent, options) {
		this.type = ATTRIBUTE_PART;
		/** @internal */
		this._$committedValue = nothing;
		/** @internal */
		this._$disconnectableChildren = void 0;
		this.element = element;
		this.name = name;
		this._$parent = parent;
		this.options = options;
		if (strings.length > 2 || strings[0] !== "" || strings[1] !== "") {
			this._$committedValue = new Array(strings.length - 1).fill(/* @__PURE__ */ new String());
			this.strings = strings;
		} else this._$committedValue = nothing;
		this._sanitizer = void 0;
	}
	/**
	* Sets the value of this part by resolving the value from possibly multiple
	* values and static strings and committing it to the DOM.
	* If this part is single-valued, `this._strings` will be undefined, and the
	* method will be called with a single value argument. If this part is
	* multi-value, `this._strings` will be defined, and the method is called
	* with the value array of the part's owning TemplateInstance, and an offset
	* into the value array from which the values should be read.
	* This method is overloaded this way to eliminate short-lived array slices
	* of the template instance values, and allow a fast-path for single-valued
	* parts.
	*
	* @param value The part value, or an array of values for multi-valued parts
	* @param valueIndex the index to start reading values from. `undefined` for
	*   single-valued parts
	* @param noCommit causes the part to not commit its value to the DOM. Used
	*   in hydration to prime attribute parts with their first-rendered value,
	*   but not set the attribute, and in SSR to no-op the DOM operation and
	*   capture the value for serialization.
	*
	* @internal
	*/
	_$setValue(value, directiveParent = this, valueIndex, noCommit) {
		const strings = this.strings;
		let change = false;
		if (strings === void 0) {
			value = resolveDirective(this, value, directiveParent, 0);
			change = !isPrimitive(value) || value !== this._$committedValue && value !== noChange;
			if (change) this._$committedValue = value;
		} else {
			const values = value;
			value = strings[0];
			let i, v;
			for (i = 0; i < strings.length - 1; i++) {
				v = resolveDirective(this, values[valueIndex + i], directiveParent, i);
				if (v === noChange) v = this._$committedValue[i];
				change ||= !isPrimitive(v) || v !== this._$committedValue[i];
				if (v === nothing) value = nothing;
				else if (value !== nothing) value += (v ?? "") + strings[i + 1];
				this._$committedValue[i] = v;
			}
		}
		if (change && !noCommit) this._commitValue(value);
	}
	/** @internal */
	_commitValue(value) {
		if (value === nothing) wrap(this.element).removeAttribute(this.name);
		else {
			if (this._sanitizer === void 0) this._sanitizer = sanitizerFactoryInternal(this.element, this.name, "attribute");
			value = this._sanitizer(value ?? "");
			debugLogEvent && debugLogEvent({
				kind: "commit attribute",
				element: this.element,
				name: this.name,
				value,
				options: this.options
			});
			wrap(this.element).setAttribute(this.name, value ?? "");
		}
	}
};
var PropertyPart = class extends AttributePart {
	constructor() {
		super(...arguments);
		this.type = PROPERTY_PART;
	}
	/** @internal */
	_commitValue(value) {
		if (this._sanitizer === void 0) this._sanitizer = sanitizerFactoryInternal(this.element, this.name, "property");
		value = this._sanitizer(value);
		debugLogEvent && debugLogEvent({
			kind: "commit property",
			element: this.element,
			name: this.name,
			value,
			options: this.options
		});
		this.element[this.name] = value === nothing ? void 0 : value;
	}
};
var BooleanAttributePart = class extends AttributePart {
	constructor() {
		super(...arguments);
		this.type = BOOLEAN_ATTRIBUTE_PART;
	}
	/** @internal */
	_commitValue(value) {
		debugLogEvent && debugLogEvent({
			kind: "commit boolean attribute",
			element: this.element,
			name: this.name,
			value: !!(value && value !== nothing),
			options: this.options
		});
		wrap(this.element).toggleAttribute(this.name, !!value && value !== nothing);
	}
};
var EventPart = class extends AttributePart {
	constructor(element, name, strings, parent, options) {
		super(element, name, strings, parent, options);
		this.type = EVENT_PART;
		if (this.strings !== void 0) throw new Error(`A \`<${element.localName}>\` has a \`@${name}=...\` listener with invalid content. Event listeners in templates must have exactly one expression and no surrounding text.`);
	}
	/** @internal */
	_$setValue(newListener, directiveParent = this) {
		newListener = resolveDirective(this, newListener, directiveParent, 0) ?? nothing;
		if (newListener === noChange) return;
		const oldListener = this._$committedValue;
		const shouldRemoveListener = newListener === nothing && oldListener !== nothing || newListener.capture !== oldListener.capture || newListener.once !== oldListener.once || newListener.passive !== oldListener.passive;
		const shouldAddListener = newListener !== nothing && (oldListener === nothing || shouldRemoveListener);
		debugLogEvent && debugLogEvent({
			kind: "commit event listener",
			element: this.element,
			name: this.name,
			value: newListener,
			options: this.options,
			removeListener: shouldRemoveListener,
			addListener: shouldAddListener,
			oldListener
		});
		if (shouldRemoveListener) this.element.removeEventListener(this.name, this, oldListener);
		if (shouldAddListener) this.element.addEventListener(this.name, this, newListener);
		this._$committedValue = newListener;
	}
	handleEvent(event) {
		if (typeof this._$committedValue === "function") this._$committedValue.call(this.options?.host ?? this.element, event);
		else this._$committedValue.handleEvent(event);
	}
};
var ElementPart = class {
	constructor(element, parent, options) {
		this.element = element;
		this.type = ELEMENT_PART;
		/** @internal */
		this._$disconnectableChildren = void 0;
		this._$parent = parent;
		this.options = options;
	}
	get _$isConnected() {
		return this._$parent._$isConnected;
	}
	_$setValue(value) {
		debugLogEvent && debugLogEvent({
			kind: "commit to element binding",
			element: this.element,
			value,
			options: this.options
		});
		resolveDirective(this, value);
	}
};
/**
* END USERS SHOULD NOT RELY ON THIS OBJECT.
*
* Private exports for use by other Lit packages, not intended for use by
* external users.
*
* We currently do not make a mangled rollup build of the lit-ssr code. In order
* to keep a number of (otherwise private) top-level exports mangled in the
* client side code, we export a _$LH object containing those members (or
* helper methods for accessing private fields of those members), and then
* re-export them for use in lit-ssr. This keeps lit-ssr agnostic to whether the
* client-side code is being used in `dev` mode or `prod` mode.
*
* This has a unique name, to disambiguate it from private exports in
* lit-element, which re-exports all of lit-html.
*
* @private
*/
var _$LH = {
	_boundAttributeSuffix: boundAttributeSuffix,
	_marker: marker,
	_markerMatch: markerMatch,
	_HTML_RESULT: HTML_RESULT,
	_getTemplateHtml: getTemplateHtml,
	_TemplateInstance: TemplateInstance,
	_isIterable: isIterable,
	_resolveDirective: resolveDirective,
	_ChildPart: ChildPart,
	_AttributePart: AttributePart,
	_BooleanAttributePart: BooleanAttributePart,
	_EventPart: EventPart,
	_PropertyPart: PropertyPart,
	_ElementPart: ElementPart
};
var polyfillSupport$1 = global$1.litHtmlPolyfillSupportDevMode;
polyfillSupport$1?.(Template, ChildPart);
(global$1.litHtmlVersions ??= []).push("3.3.3");
if (global$1.litHtmlVersions.length > 1) queueMicrotask(() => {
	issueWarning$3("multiple-versions", "Multiple versions of Lit loaded. Loading multiple versions is not recommended.");
});
/**
* Renders a value, usually a lit-html TemplateResult, to the container.
*
* This example renders the text "Hello, Zoe!" inside a paragraph tag, appending
* it to the container `document.body`.
*
* ```js
* import {html, render} from 'lit';
*
* const name = "Zoe";
* render(html`<p>Hello, ${name}!</p>`, document.body);
* ```
*
* @param value Any [renderable
*   value](https://lit.dev/docs/templates/expressions/#child-expressions),
*   typically a {@linkcode TemplateResult} created by evaluating a template tag
*   like {@linkcode html} or {@linkcode svg}.
* @param container A DOM container to render to. The first render will append
*   the rendered value to the container, and subsequent renders will
*   efficiently update the rendered value if the same result type was
*   previously rendered there.
* @param options See {@linkcode RenderOptions} for options documentation.
* @see
* {@link https://lit.dev/docs/libraries/standalone-templates/#rendering-lit-html-templates| Rendering Lit HTML Templates}
*/
var render = (value, container, options) => {
	if (container == null) throw new TypeError(`The container to render into may not be ${container}`);
	const renderId = debugLogRenderId++;
	const partOwnerNode = options?.renderBefore ?? container;
	let part = partOwnerNode["_$litPart$"];
	debugLogEvent && debugLogEvent({
		kind: "begin render",
		id: renderId,
		value,
		container,
		options,
		part
	});
	if (part === void 0) {
		const endNode = options?.renderBefore ?? null;
		partOwnerNode["_$litPart$"] = part = new ChildPart(container.insertBefore(createMarker(), endNode), endNode, void 0, options ?? {});
	}
	part._$setValue(value);
	debugLogEvent && debugLogEvent({
		kind: "end render",
		id: renderId,
		value,
		container,
		options,
		part
	});
	return part;
};
render.setSanitizer = setSanitizer;
render.createSanitizer = createSanitizer;
render._testOnlyClearSanitizerFactoryDoNotCallOrElse = _testOnlyClearSanitizerFactoryDoNotCallOrElse;
// node_modules/lit-element/development/lit-element.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
/**
* The main LitElement module, which defines the {@linkcode LitElement} base
* class and related APIs.
*
* LitElement components can define a template and a set of observed
* properties. Changing an observed property triggers a re-render of the
* element.
*
* Import {@linkcode LitElement} and {@linkcode html} from this module to
* create a component:
*
*  ```js
* import {LitElement, html} from 'lit-element';
*
* class MyElement extends LitElement {
*
*   // Declare observed properties
*   static get properties() {
*     return {
*       adjective: {}
*     }
*   }
*
*   constructor() {
*     this.adjective = 'awesome';
*   }
*
*   // Define the element's template
*   render() {
*     return html`<p>your ${adjective} template here</p>`;
*   }
* }
*
* customElements.define('my-element', MyElement);
* ```
*
* `LitElement` extends {@linkcode ReactiveElement} and adds lit-html
* templating. The `ReactiveElement` class is provided for users that want to
* build their own custom element base classes that don't use lit-html.
*
* @packageDocumentation
*/
var JSCompiler_renameProperty = (prop, _obj) => prop;
var global = globalThis;
var issueWarning$2;
global.litIssuedWarnings ??= /* @__PURE__ */ new Set();
/**
* Issue a warning if we haven't already, based either on `code` or `warning`.
* Warnings are disabled automatically only by `warning`; disabling via `code`
* can be done by users.
*/
issueWarning$2 = (code, warning) => {
	warning += ` See https://lit.dev/msg/${code} for more information.`;
	if (!global.litIssuedWarnings.has(warning) && !global.litIssuedWarnings.has(code)) {
		console.warn(warning);
		global.litIssuedWarnings.add(warning);
	}
};
/**
* Base element class that manages element properties and attributes, and
* renders a lit-html template.
*
* To define a component, subclass `LitElement` and implement a
* `render` method to provide the component's template. Define properties
* using the {@linkcode LitElement.properties properties} property or the
* {@linkcode property} decorator.
*/
var LitElement = class extends ReactiveElement {
	constructor() {
		super(...arguments);
		/**
		* @category rendering
		*/
		this.renderOptions = { host: this };
		this.__childPart = void 0;
	}
	/**
	* @category rendering
	*/
	createRenderRoot() {
		const renderRoot = super.createRenderRoot();
		this.renderOptions.renderBefore ??= renderRoot.firstChild;
		return renderRoot;
	}
	/**
	* Updates the element. This method reflects property values to attributes
	* and calls `render` to render DOM via lit-html. Setting properties inside
	* this method will *not* trigger another update.
	* @param changedProperties Map of changed properties with old values
	* @category updates
	*/
	update(changedProperties) {
		const value = this.render();
		if (!this.hasUpdated) this.renderOptions.isConnected = this.isConnected;
		super.update(changedProperties);
		this.__childPart = render(value, this.renderRoot, this.renderOptions);
	}
	/**
	* Invoked when the component is added to the document's DOM.
	*
	* In `connectedCallback()` you should setup tasks that should only occur when
	* the element is connected to the document. The most common of these is
	* adding event listeners to nodes external to the element, like a keydown
	* event handler added to the window.
	*
	* ```ts
	* connectedCallback() {
	*   super.connectedCallback();
	*   addEventListener('keydown', this._handleKeydown);
	* }
	* ```
	*
	* Typically, anything done in `connectedCallback()` should be undone when the
	* element is disconnected, in `disconnectedCallback()`.
	*
	* @category lifecycle
	*/
	connectedCallback() {
		super.connectedCallback();
		this.__childPart?.setConnected(true);
	}
	/**
	* Invoked when the component is removed from the document's DOM.
	*
	* This callback is the main signal to the element that it may no longer be
	* used. `disconnectedCallback()` should ensure that nothing is holding a
	* reference to the element (such as event listeners added to nodes external
	* to the element), so that it is free to be garbage collected.
	*
	* ```ts
	* disconnectedCallback() {
	*   super.disconnectedCallback();
	*   window.removeEventListener('keydown', this._handleKeydown);
	* }
	* ```
	*
	* An element may be re-connected after being disconnected.
	*
	* @category lifecycle
	*/
	disconnectedCallback() {
		super.disconnectedCallback();
		this.__childPart?.setConnected(false);
	}
	/**
	* Invoked on each update to perform rendering tasks. This method may return
	* any value renderable by lit-html's `ChildPart` - typically a
	* `TemplateResult`. Setting properties inside this method will *not* trigger
	* the element to update.
	* @category rendering
	*/
	render() {
		return noChange;
	}
};
LitElement["_$litElement$"] = true;
/**
* Ensure this class is marked as `finalized` as an optimization ensuring
* it will not needlessly try to `finalize`.
*
* Note this property name is a string to prevent breaking Closure JS Compiler
* optimizations. See @lit/reactive-element for more information.
*/
LitElement[JSCompiler_renameProperty("finalized", LitElement)] = true;
global.litElementHydrateSupport?.({ LitElement });
var polyfillSupport = global.litElementPolyfillSupportDevMode;
polyfillSupport?.({ LitElement });
(global.litElementVersions ??= []).push("4.2.2");
if (global.litElementVersions.length > 1) queueMicrotask(() => {
	issueWarning$2("multiple-versions", "Multiple versions of Lit loaded. Loading multiple versions is not recommended.");
});
// node_modules/@awesome.me/webawesome/dist/chunks/chunk.7VGCIHDG.js
/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __typeError = (msg) => {
	throw TypeError(msg);
};
var __decorateClass = (decorators, target, key, kind) => {
	var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
	for (var i = decorators.length - 1, decorator; i >= 0; i--) if (decorator = decorators[i]) result = (kind ? decorator(target, key, result) : decorator(result)) || result;
	if (kind && result) __defProp(target, key, result);
	return result;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
// node_modules/@lit/reactive-element/development/decorators/custom-element.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
/**
* Class decorator factory that defines the decorated class as a custom element.
*
* ```js
* @customElement('my-element')
* class MyElement extends LitElement {
*   render() {
*     return html``;
*   }
* }
* ```
* @category Decorator
* @param tagName The tag name of the custom element to define.
*/
var customElement = (tagName) => (classOrTarget, context) => {
	if (context !== void 0) context.addInitializer(() => {
		customElements.define(tagName, classOrTarget);
	});
	else customElements.define(tagName, classOrTarget);
};
// node_modules/@lit/reactive-element/development/decorators/property.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
var issueWarning$1;
globalThis.litIssuedWarnings ??= /* @__PURE__ */ new Set();
/**
* Issue a warning if we haven't already, based either on `code` or `warning`.
* Warnings are disabled automatically only by `warning`; disabling via `code`
* can be done by users.
*/
issueWarning$1 = (code, warning) => {
	warning += ` See https://lit.dev/msg/${code} for more information.`;
	if (!globalThis.litIssuedWarnings.has(warning) && !globalThis.litIssuedWarnings.has(code)) {
		console.warn(warning);
		globalThis.litIssuedWarnings.add(warning);
	}
};
var legacyProperty = (options, proto, name) => {
	const hasOwnProperty = proto.hasOwnProperty(name);
	proto.constructor.createProperty(name, options);
	return hasOwnProperty ? Object.getOwnPropertyDescriptor(proto, name) : void 0;
};
var defaultPropertyDeclaration = {
	attribute: true,
	type: String,
	converter: defaultConverter,
	reflect: false,
	hasChanged: notEqual
};
/**
* Wraps a class accessor or setter so that `requestUpdate()` is called with the
* property name and old value when the accessor is set.
*/
var standardProperty = (options = defaultPropertyDeclaration, target, context) => {
	const { kind, metadata } = context;
	if (metadata == null) issueWarning$1("missing-class-metadata", `The class ${target} is missing decorator metadata. This could mean that you're using a compiler that supports decorators but doesn't support decorator metadata, such as TypeScript 5.1. Please update your compiler.`);
	let properties = globalThis.litPropertyMetadata.get(metadata);
	if (properties === void 0) globalThis.litPropertyMetadata.set(metadata, properties = /* @__PURE__ */ new Map());
	if (kind === "setter") {
		options = Object.create(options);
		options.wrapped = true;
	}
	properties.set(context.name, options);
	if (kind === "accessor") {
		const { name } = context;
		return {
			set(v) {
				const oldValue = target.get.call(this);
				target.set.call(this, v);
				this.requestUpdate(name, oldValue, options, true, v);
			},
			init(v) {
				if (v !== void 0) this._$changeProperty(name, void 0, options, v);
				return v;
			}
		};
	} else if (kind === "setter") {
		const { name } = context;
		return function(value) {
			const oldValue = this[name];
			target.call(this, value);
			this.requestUpdate(name, oldValue, options, true, value);
		};
	}
	throw new Error(`Unsupported decorator location: ${kind}`);
};
/**
* A class field or accessor decorator which creates a reactive property that
* reflects a corresponding attribute value. When a decorated property is set
* the element will update and render. A {@linkcode PropertyDeclaration} may
* optionally be supplied to configure property features.
*
* This decorator should only be used for public fields. As public fields,
* properties should be considered as primarily settable by element users,
* either via attribute or the property itself.
*
* Generally, properties that are changed by the element should be private or
* protected fields and should use the {@linkcode state} decorator.
*
* However, sometimes element code does need to set a public property. This
* should typically only be done in response to user interaction, and an event
* should be fired informing the user; for example, a checkbox sets its
* `checked` property when clicked and fires a `changed` event. Mutating public
* properties should typically not be done for non-primitive (object or array)
* properties. In other cases when an element needs to manage state, a private
* property decorated via the {@linkcode state} decorator should be used. When
* needed, state properties can be initialized via public properties to
* facilitate complex interactions.
*
* ```ts
* class MyElement {
*   @property({ type: Boolean })
*   clicked = false;
* }
* ```
* @category Decorator
* @ExportDecoratedItems
*/
function property(options) {
	return (protoOrTarget, nameOrContext) => {
		return typeof nameOrContext === "object" ? standardProperty(options, protoOrTarget, nameOrContext) : legacyProperty(options, protoOrTarget, nameOrContext);
	};
}
// node_modules/@lit/reactive-element/development/decorators/state.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
/**
* Declares a private or protected reactive property that still triggers
* updates to the element when it changes. It does not reflect from the
* corresponding attribute.
*
* Properties declared this way must not be used from HTML or HTML templating
* systems, they're solely for properties internal to the element. These
* properties may be renamed by optimization tools like closure compiler.
* @category Decorator
*/
function state(options) {
	return property({
		...options,
		state: true,
		attribute: false
	});
}
// node_modules/@lit/reactive-element/development/decorators/base.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
/**
* Wraps up a few best practices when returning a property descriptor from a
* decorator.
*
* Marks the defined property as configurable, and enumerable, and handles
* the case where we have a busted Reflect.decorate zombiefill (e.g. in Angular
* apps).
*
* @internal
*/
var desc = (obj, name, descriptor) => {
	descriptor.configurable = true;
	descriptor.enumerable = true;
	if (Reflect.decorate && typeof name !== "object") Object.defineProperty(obj, name, descriptor);
	return descriptor;
};
// node_modules/@lit/reactive-element/development/decorators/query.js
/**
* @license
* Copyright 2017 Google LLC
* SPDX-License-Identifier: BSD-3-Clause
*/
var issueWarning;
globalThis.litIssuedWarnings ??= /* @__PURE__ */ new Set();
/**
* Issue a warning if we haven't already, based either on `code` or `warning`.
* Warnings are disabled automatically only by `warning`; disabling via `code`
* can be done by users.
*/
issueWarning = (code, warning) => {
	warning += code ? ` See https://lit.dev/msg/${code} for more information.` : "";
	if (!globalThis.litIssuedWarnings.has(warning) && !globalThis.litIssuedWarnings.has(code)) {
		console.warn(warning);
		globalThis.litIssuedWarnings.add(warning);
	}
};
/**
* A property decorator that converts a class property into a getter that
* executes a querySelector on the element's renderRoot.
*
* @param selector A DOMString containing one or more selectors to match.
* @param cache An optional boolean which when true performs the DOM query only
*     once and caches the result.
*
* See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
*
* ```ts
* class MyElement {
*   @query('#first')
*   first: HTMLDivElement;
*
*   render() {
*     return html`
*       <div id="first"></div>
*       <div id="second"></div>
*     `;
*   }
* }
* ```
* @category Decorator
*/
function query(selector, cache) {
	return ((protoOrTarget, nameOrContext, descriptor) => {
		const doQuery = (el) => {
			const result = el.renderRoot?.querySelector(selector) ?? null;
			if (result === null && cache && !el.hasUpdated) {
				const name = typeof nameOrContext === "object" ? nameOrContext.name : nameOrContext;
				issueWarning("", `@query'd field ${JSON.stringify(String(name))} with the 'cache' flag set for selector '${selector}' has been accessed before the first update and returned null. This is expected if the renderRoot tree has not been provided beforehand (e.g. via Declarative Shadow DOM). Therefore the value hasn't been cached.`);
			}
			return result;
		};
		if (cache) {
			const { get, set } = typeof nameOrContext === "object" ? protoOrTarget : descriptor ?? (() => {
				const key = Symbol(`${String(nameOrContext)} (@query() cache)`);
				return {
					get() {
						return this[key];
					},
					set(v) {
						this[key] = v;
					}
				};
			})();
			return desc(protoOrTarget, nameOrContext, { get() {
				let result = get.call(this);
				if (result === void 0) {
					result = doQuery(this);
					if (result !== null || this.hasUpdated) set.call(this, result);
				}
				return result;
			} });
		} else return desc(protoOrTarget, nameOrContext, { get() {
			return doQuery(this);
		} });
	});
}
// node_modules/@awesome.me/webawesome/dist/chunks/chunk.AOKMSJXD.js
/*! Copyright 2026 Fonticons, Inc. - https://webawesome.com/license */
var host_styles_default = css`
  :host {
    box-sizing: border-box;
  }

  :host *,
  :host *::before,
  :host *::after {
    box-sizing: inherit;
  }

  [hidden],
  :host([hidden]) {
    display: none !important;
  }
`;
var HAS_ENDING_COLON = /;\s+$/;
function camelToKebab(str) {
	return str.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);
}
function buildStyleAttribute(options) {
	const { property: property2, value, element } = options;
	if (value) {
		let style = element.getAttribute("style") || "";
		if (style) {
			if (!style.match(HAS_ENDING_COLON)) style += ";";
			style += " ";
		}
		const str = `${property2}: ${value}`;
		if (style.includes(str)) return;
		return `${style}${str};`;
	}
	return null;
}
var _hasRecordedInitialProperties;
var WebAwesomeElement = class extends LitElement {
	constructor() {
		super();
		__privateAdd(this, _hasRecordedInitialProperties, false);
		this.initialReflectedProperties = /* @__PURE__ */ new Map();
		this.didSSR = Boolean(this.shadowRoot);
		/**
		* @internal Methods for setting and checking custom states.
		*/
		this.customStates = {
			/** Adds or removes the specified custom state. */
			set: (customState, active) => {
				if (!Boolean(this.internals?.states)) return;
				try {
					if (active) this.internals.states.add(customState);
					else this.internals.states.delete(customState);
				} catch (e) {
					if (String(e).includes("must start with '--'")) console.error("Your browser implements an outdated version of CustomStateSet. Consider using a polyfill");
					else throw e;
				}
			},
			/** Determines whether or not the element currently has the specified state. */
			has: (customState) => {
				if (!Boolean(this.internals?.states)) return false;
				try {
					return this.internals.states.has(customState);
				} catch {
					return false;
				}
			}
		};
		try {
			this.internals = this.attachInternals();
		} catch {
			console.error("Element internals are not supported in your browser. Consider using a polyfill");
		}
		this.customStates.set("wa-defined", true);
		let Self = this.constructor;
		for (let [property2, spec] of Self.elementProperties) if (spec.default === "inherit" && spec.initial !== void 0 && typeof property2 === "string") this.customStates.set(`initial-${property2}-${spec.initial}`, true);
	}
	/** Prepends host styles to the component's styles. */
	static get styles() {
		return [host_styles_default, ...Array.isArray(this.css) ? this.css : this.css ? [this.css] : []];
	}
	connectedCallback() {
		super.connectedCallback();
		if (!this.didSSR) this.shadowRoot?.prepend(document.createComment(` Web Awesome: https://webawesome.com/docs/components/${this.localName.replace("wa-", "")} `));
		if (this.didSSR) this.updateComplete.then(() => {
			this.shadowRoot?.prepend(document.createComment(` Web Awesome: https://webawesome.com/docs/components/${this.localName.replace("wa-", "")} `));
		});
	}
	attributeChangedCallback(name, oldValue, newValue) {
		if (!__privateGet(this, _hasRecordedInitialProperties)) {
			this.constructor.elementProperties.forEach((obj, prop) => {
				if (obj.reflect && this[prop] != null) this.initialReflectedProperties.set(prop, this[prop]);
			});
			__privateSet(this, _hasRecordedInitialProperties, true);
		}
		super.attributeChangedCallback(name, oldValue, newValue);
	}
	willUpdate(changedProperties) {
		super.willUpdate(changedProperties);
		this.initialReflectedProperties.forEach((value, prop) => {
			if (changedProperties.has(prop) && this[prop] == null) this[prop] = value;
		});
	}
	firstUpdated(changedProperties) {
		super.firstUpdated(changedProperties);
		if (this.didSSR) this.shadowRoot?.querySelectorAll("slot").forEach((slotElement) => {
			slotElement.dispatchEvent(new Event("slotchange", {
				bubbles: true,
				composed: false,
				cancelable: false
			}));
		});
	}
	update(changedProperties) {
		try {
			super.update(changedProperties);
		} catch (e) {
			if (this.didSSR && !this.hasUpdated) {
				const event = new Event("lit-hydration-error", {
					bubbles: true,
					composed: true,
					cancelable: false
				});
				event.error = e;
				this.dispatchEvent(event);
			}
			throw e;
		}
	}
	/**
	* @internal
	* Internal way to set styles across both client and server
	*/
	setStyle(property2, value) {
		if (!this.style) {
			const str = buildStyleAttribute({
				property: camelToKebab(property2),
				value,
				element: this
			});
			if (str) this.setAttribute("style", str);
			return;
		}
		this.style[property2] = value;
	}
	/**
	* @internal
	* Internal way to set a CSS custom property across both client and server.
	*/
	setStyleProperty(property2, value) {
		if (!this.style) {
			const str = buildStyleAttribute({
				property: property2,
				value,
				element: this
			});
			if (str) this.setAttribute("style", str);
			return;
		}
		this.style.setProperty(property2, value);
	}
	/**
	* @internal Given a native event, this function cancels it and dispatches it again from the host element using the desired
	* event options.
	*/
	relayNativeEvent(event, eventOptions) {
		event.stopImmediatePropagation();
		this.dispatchEvent(new event.constructor(event.type, {
			...event,
			...eventOptions
		}));
	}
};
_hasRecordedInitialProperties = /* @__PURE__ */ new WeakMap();
__decorateClass([property()], WebAwesomeElement.prototype, "dir", 2);
__decorateClass([property()], WebAwesomeElement.prototype, "lang", 2);
__decorateClass([property({
	type: Boolean,
	reflect: true,
	attribute: "did-ssr"
})], WebAwesomeElement.prototype, "didSSR", 2);
export { customElement as a, html as c, nothing as d, svg as f, property as i, mathml as l, query as n, __decorateClass as o, css as p, state as r, _$LH as s, WebAwesomeElement as t, noChange as u };
